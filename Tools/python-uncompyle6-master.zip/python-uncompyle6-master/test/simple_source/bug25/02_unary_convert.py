# Python 2's deprecated unary convert (akin to "repr()"
`abc`

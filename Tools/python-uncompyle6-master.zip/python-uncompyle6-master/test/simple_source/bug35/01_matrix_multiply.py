# Tests Python 3.5+'s ops

# BINARY_MATRIX_MULTIPLY and INPLACE_MATRIX_MULTIPLY
# code taken from pycdc tests/35_matrix_mult_oper.pyc.src

m = [1, 2] @ [3, 4]
m @= [5, 6]

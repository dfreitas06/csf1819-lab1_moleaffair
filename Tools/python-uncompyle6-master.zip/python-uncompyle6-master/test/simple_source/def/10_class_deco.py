# From 3.4 tracemalloc.py
from functools import total_ordering

@total_ordering
class Frame:
    pass

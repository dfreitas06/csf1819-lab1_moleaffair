# 2.6.9 text_file.py
# Bugs in 2.6 and 2.7 detecting structure
def readline (self):
    while 1:
        if self:
            if __file__:
                continue

        return

# Tests:
#  forstmt ::= SETUP_LOOP expr _for store
#              for_block POP_BLOCK COME_FROM
for a in [1]:
    c = 2

for a in range(2):
    c = 2

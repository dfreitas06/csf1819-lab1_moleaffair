The tests here are the tests from decomplyle version 2.4, 02 Jan 2006

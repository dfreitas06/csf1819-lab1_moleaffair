
for i in range(20):
    print i,

print

for i in range(10):
    print i,
    #if i == 10: break
else:
    print 'The End'
